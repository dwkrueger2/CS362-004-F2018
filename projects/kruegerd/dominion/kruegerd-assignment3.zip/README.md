// This folder contains the modified source code used for user: kruegerd
//			Code Modified for Assignment 2 and 3. 
//			Current Version - Assignment 3 -- see source control for other versions
8 Tests are created unittests[1-4].c and cardtest[1-4].c
The 8 tests are run in a unified manner in testSuite.c


Makefile provided:

To Build type 'make testSuite'
to run type 'testSuite' 

To Run the test suite and generate coverage and capture output data 
run 'make testALL'.  If this option is chosen then the file 'unittestresult.out' will
show coverage data of the dominion.c file.

to clean up object files run 'make clean'


/// Summary of Modifications
///		Assignment 2 Modification -- see ../CLASS_INFO/Assignment 2 Resources/ kruegerd-Assignment2.pdf
///		Assignmnet 3 Modification  -- see ../CLASS_INFO/Assignment 3 Resources/ kruegerd-Assignment3.pdf

